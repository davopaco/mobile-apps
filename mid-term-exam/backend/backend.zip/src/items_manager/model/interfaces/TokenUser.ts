export default interface TokenUser {
  username: string;
  name: string;
}
