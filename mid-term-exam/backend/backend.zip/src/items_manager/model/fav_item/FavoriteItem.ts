import AFavoriteItem from "./AFavoriteItem";

export default class FavoriteItem extends AFavoriteItem {
  isNull(): boolean {
    return false;
  }
}
