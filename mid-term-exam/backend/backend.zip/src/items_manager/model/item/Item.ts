import AItem from "./AItem";

export default class Item extends AItem {
  isNull(): boolean {
    return false;
  }
}
