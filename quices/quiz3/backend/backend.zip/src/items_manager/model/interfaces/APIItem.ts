export default interface APIItem {
  name: string;
  vendor: string;
  rating: number;
  imagePath: string;
}
