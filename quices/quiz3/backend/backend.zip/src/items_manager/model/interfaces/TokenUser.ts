export default interface TokenUser {
  username: string;
  name: string;
  password?: string;
  session: number;
}
