import AUser from "./AUser";

export default class User extends AUser {
  isNull(): boolean {
    return false;
  }
}
