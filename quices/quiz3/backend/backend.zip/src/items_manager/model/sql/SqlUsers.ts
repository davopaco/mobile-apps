export default interface SqlUsers {
  USERNAME: string;
  NAME: string;
  HASH: string;
}
