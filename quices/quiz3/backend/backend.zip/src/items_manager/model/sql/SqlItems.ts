export default interface SqlItems {
  ID: number;
  NAME: string;
  VENDOR: string;
  RATING: number;
  IMAGE_PATH: string;
}
