import APosition from "./APosition";

export default class Position extends APosition {
  isNull(): boolean {
    return false;
  }
}
