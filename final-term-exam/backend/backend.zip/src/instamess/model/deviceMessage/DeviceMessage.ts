import ADeviceMessage from "./ADeviceMessage";

export default class DeviceMessage extends ADeviceMessage {
  public isNull(): boolean {
    return false;
  }
}
