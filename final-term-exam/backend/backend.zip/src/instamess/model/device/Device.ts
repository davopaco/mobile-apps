import ADevice from "./ADevice";

export default class Device extends ADevice {
  isNull(): boolean {
    return false;
  }
}
