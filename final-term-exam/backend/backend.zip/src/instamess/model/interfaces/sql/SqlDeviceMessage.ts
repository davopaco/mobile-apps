export default interface SqlDeviceMessage {
  DEVICE_ID: number;
  MESSAGE_ID: number;
  RESPONSE: string;
}
