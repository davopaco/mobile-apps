export default interface SqlUserDevice {
  USER_EMAIL: string;
  DEVICE_ID: number;
  LOGGED: number;
}
