export default interface SqlDevice {
  ID: number;
  FCM_TOKEN: string;
}
