export default interface SqlPosition {
  ID: number;
  NAME: string;
}
