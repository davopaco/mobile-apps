export default interface HttpUserMessage {
  title: string;
  content: string;
  recipientEmail: string;
  email: string;
}
