export default interface HttpLoginUser {
  email: string;
  password: string;
  fcmToken: string;
}
