export default interface UserReturn {
  email: string;
  name: string;
  position: string;
  pfp: string;
  phone: number;
  sameUser: boolean;
}
