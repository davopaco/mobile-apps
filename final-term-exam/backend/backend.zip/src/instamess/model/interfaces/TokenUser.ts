export default interface TokenUser {
  email: string;
  name: string;
}
