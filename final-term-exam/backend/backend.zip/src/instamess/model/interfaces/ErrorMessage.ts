export default interface ErrorMessage {
  error: boolean;
  message: string;
}
