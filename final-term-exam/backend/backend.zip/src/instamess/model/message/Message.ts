import AMessage from "./AMessage";

export default class Message extends AMessage {
  public isNull(): boolean {
    return false;
  }
}
