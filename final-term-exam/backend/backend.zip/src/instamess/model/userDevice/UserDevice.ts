import AUserDevice from "./AUserDevice";

export default class UserDevice extends AUserDevice {
  public isNull(): boolean {
    return false;
  }
}
