export default interface MySqlConnectionConfig {
  host: string;
  user: string;
  password: string;
  database: string;
  port: number;
}
